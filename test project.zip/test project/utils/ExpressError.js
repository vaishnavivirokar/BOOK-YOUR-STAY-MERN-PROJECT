class ExpressError extends Error {
    constructor(statusCode, message) {
        super();
        this.statusCode = statusCode;
        this.message = message;
    }
}

module.exports = ExpressError;

const ExpressError = require("./utils/ExpressError.js");

let {statusCode, message} = err;
res.satus(statusCode).send(message);

app.all("*", (req, res, next) => {
  next(new ExpressError(404, "Page not found!"));
});

if(!req.body.listing) {
  throw new ExpressError(404, "Send valid data for listing");
}

