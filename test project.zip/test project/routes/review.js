const express = require("express");
const router = express.Router({mergeParams: true});
const wrapAsync = require ("../utils/wrapAsync.js");
const Review = require("../models/review.js"); 
const Listing = require("../models/listing.js"); 
const { createReview } = require("../controllers/reviews.js");



const reviewController= require("../controllers/reviews.js")
//Review
//Post review Rout
router.post("/", wrapAsync(reviewController.createReview));
  
  //Delete review rout :
  router.delete("/:reviewId", wrapAsync(reviewController.destroyReview));
  
  module .exports = router;